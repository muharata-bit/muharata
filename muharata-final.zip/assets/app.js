const machines=[
["01","milling","Posho Mills","Practical milling solutions for different production requirements."],
["02","milling","Maize Hullers","Equipment for efficient maize processing and preparation."],
["03","milling","Polishers","Post-milling equipment for improved grain preparation."],
["04","milling","Sifted Maize Mills","Milling systems for sifted maize production."],
["05","animal","Feed Mills","Processing equipment for poultry, livestock and other feed applications."],
["06","animal","Feed Mixers","Durable, practical mixing solutions in different configurations."],
["07","animal","Silage Choppers","Compact processing solutions combining chopping and feed preparation."],
["08","animal","Chaff Cutters","Fodder preparation equipment for livestock production."],
["09","animal","Hay Balers","Equipment for baling and handling hay and fodder."],
["10","specialized","Oil Presses","Specialized equipment for oilseed processing applications."],
["11","specialized","Root & Tuber Processing","Custom equipment for selected root and tuber processing needs."],
["12","specialized","Peanut Processing","Machinery for selected peanut processing applications."],
["13","specialized","Bone Mills","Heavy-duty grinding equipment for dry bone and related materials."],
["14","specialized","Charcoal Briquetting","Equipment for forming biomass and charcoal briquettes."],
["15","post","Threshers & Processing","Machinery designed for post-harvest handling and processing workflows."],
["16","post","Chia Seed Threshers","Specialized threshing equipment for selected seed crops."],
["17","post","Storage & Silos","Storage-related equipment for grain and processing operations."],
["18","post","Drying Solutions","Post-harvest drying solutions for processing workflows."]
];
const grid=document.querySelector("#machineGrid");
function render(filter="all"){grid.innerHTML=machines.filter(x=>filter==="all"||x[1]===filter).map(x=>`<article class="card"><div><span class="num">${x[0]} · ${x[1].toUpperCase()}</span><h3>${x[2]}</h3><p>${x[3]}</p></div><a href="#quote" data-machine="${x[2]}">Request details →</a></article>`).join("");}
render();
document.querySelectorAll(".filters button").forEach(b=>b.addEventListener("click",()=>{document.querySelectorAll(".filters button").forEach(x=>x.classList.remove("active"));b.classList.add("active");render(b.dataset.filter)}));
document.addEventListener("click",e=>{if(e.target.matches("[data-machine]")){e.preventDefault();document.querySelector("#quote").scrollIntoView({behavior:"smooth"});setTimeout(()=>{document.querySelector('[name="machine"]').value=e.target.dataset.machine},400)}});
document.querySelector(".menu").addEventListener("click",()=>{const n=document.querySelector("nav");n.style.display=n.style.display==="flex"?"none":"flex";n.style.flexDirection="column";n.style.position="absolute";n.style.top="75px";n.style.right="6%";n.style.background="#fff";n.style.padding="20px";n.style.boxShadow="0 15px 35px #0002"});
document.querySelector("#quoteForm").addEventListener("submit",e=>{e.preventDefault();const f=new FormData(e.target);const msg=`Hello Muharata, my name is ${f.get("name")}. I am enquiring about ${f.get("machine")}. Phone: ${f.get("phone")}. ${f.get("message")||""}`;document.querySelector("#formNote").textContent="Opening WhatsApp to send your enquiry…";window.open("https://wa.me/254785756215?text="+encodeURIComponent(msg),"_blank")});
